let songs = [
    {
        name: 'song 1',
        path: 'Audio/Untitled.mp3',
        artist: 'artist 1',
        cover: 'images/kr$na.png'
    },
    {
        name: 'song 2',
        path: 'musics/Song 2.mp3',
        artist: 'artist 2',
        cover: 'images/Badshah.png'
    },
    {
        name: 'song 3',
        path: 'musics/Song 3.mp3',
        artist: 'artist 3',
        cover: 'images/cover 3.png'
    },
    {
        name: 'song 4',
        path: 'musics/Song 4.mp3',
        artist: 'artist 4',
        cover: 'images/cover 4.png'
    },
    {
        name: 'song 5',
        path: 'musics/Song 5.mp3',
        artist: 'artist 5',
        cover: 'images/cover 5.png'
    },
]